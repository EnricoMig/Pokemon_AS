/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exemplopokemon;

/**
 *
 * @author bruno
 */
public class Charmander implements Pokemon{
    private int HP;
    private int ATK;
    private int DEF;
    
    private String tipo;
    private String[] fraco;
    private String[] forte;
    
    public Charmander(){
        this.HP = 1;
        this.ATK = 2;
        this.DEF = 3;
        
        this.tipo = "eletrico";
        
        this.fraco = new String[2];
        this.fraco[0] = "fogo";
        this.fraco[1] = "pedra";
        
        this.forte = new String[2];
        this.forte[0] = "eletrico";
        this.forte[1] = "agua";  
    }

    @Override
    public int getHP() {
        return HP;
    }
    
    @Override
    public void setHP(int hp) {
        this.HP = hp;
    }

    @Override
    public int getATK() {
        return ATK;
    }

    @Override
    public int getDEF() {
        return DEF;
    }

    @Override
    public String getTipo() {
        return tipo;
    }

    @Override
    public String[] getFraco() {
        return fraco;
    }

    @Override
    public String[] getForte() {
        return forte;
    }
      
}
