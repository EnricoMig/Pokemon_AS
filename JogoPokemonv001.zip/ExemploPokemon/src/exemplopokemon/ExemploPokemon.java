/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exemplopokemon;

/**
 *
 * @author bruno
 */
public class ExemploPokemon {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Jogador j = new Jogador();
        
        Pokemon p1 = new Charmander();
        Pokemon p2 = new Pikachu();
        System.out.println(p2.getHP());
        
        j.sofreDano(p2);
        System.out.println(p2.getHP());
        
         
        System.out.println(j.ehForte(p2, p1));
        
    }
    
}
