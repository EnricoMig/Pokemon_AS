/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exemplopokemon;

/**
 *
 * @author bruno
 */
public class Jogador {
    
    public void sofreDano(Pokemon p){
        
        System.out.println(p.getClass().getSimpleName().equals("Charmander"));
        
        if (p.getClass().getSimpleName().equals("Charmander")) {
            p.setHP(p.getHP()-2);
        } else {
            p.setHP(p.getHP()-1);
        }
    }
    
    public boolean ehForte(Pokemon pAtaca, Pokemon pDefende) {
        
        String[] lista = pAtaca.getForte();
        int forte = 0;
        for (String f: lista) {
            if (f.equals(pDefende.getTipo())) {
                forte++;
            }
        }
        
        if (forte == 0) {
            return false;
        } else {return true;}        
    }
    
    
}
