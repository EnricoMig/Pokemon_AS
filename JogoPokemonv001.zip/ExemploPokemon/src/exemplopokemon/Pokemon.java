/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package exemplopokemon;

/**
 *
 * @author bruno
 */
public interface Pokemon {
   public int getHP();
   public void setHP(int hp);
   public int getATK();
   public int getDEF();
   public String getTipo();
   public String[] getFraco();
   public String[] getForte();
   
}
